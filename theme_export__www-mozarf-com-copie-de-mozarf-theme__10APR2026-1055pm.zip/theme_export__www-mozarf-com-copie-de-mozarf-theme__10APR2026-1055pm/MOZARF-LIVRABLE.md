# MOZARF — Livrable final (spec + thème + mise en route)

Document unique qui reprend **tout ce qui a été demandé** pour la boutique type BeatStars, **ce qui est en place dans le thème**, et **ce que tu dois faire dans l’admin Shopify**.

---

## 1. Rappel de ta spec (objectifs)

| Besoin | Détail |
|--------|--------|
| Plateforme | **Shopify** comme base ; lien **externe BeatStars** si tu veux rediriger ou doubler les ventes. |
| Offre | **Pas de “single” comme produit principal** : **un album = un produit Shopify**, avec possibilité d’**acheter chaque morceau séparément** (via variantes dédiées dans le JSON). |
| Formats | Sur **la même page** (modale) : **MP3**, **WAV**, **pack stems**, **licence pro** — boutons qui ajoutent la bonne variante au panier. |
| UX | **Modale plein écran**, arrière-plan **légèrement visible** (flou), albums derrière ; **comportement identique sur mobile**. |
| Préécoute | **30 secondes** (réglable par section). |
| Identité | **Noir + bleu MOZARF** (variables CSS `--mozarf-*` dans `mozarf-marketplace.css`). |
| Accueil | **Nouvel album en vitrine** + **mini description** (section dédiée). |
| Collections | Esprit **[BeatStars explore collections](https://www.beatstars.com/explore-collections)** ; au clic sur un album, **fiche modale** ; **autres albums visibles** en dessous (grille collection + grille “more” sur la vitrine). |
| Référence album | Ex. [collection BeatStars](https://www.beatstars.com/collection/191526) — chez toi : grille Shopify + modale. |
| Filtres | **Recherche / filtres** via le snippet **facets** du thème (filtres collection Shopify). |
| Drum kits | Liste type **[explore sound kits](https://www.beatstars.com/explore-sound-kits)** ; **fiche produit centrée** (pas collée à gauche comme [cet exemple](https://www.beatstars.com/travabeats/sound-kits/257242)) → template **`product.mozarf-kit`** + CSS. |
| International | Boutique **en anglais**, **multi-devises** et **multi-langues** → réglages **Shopify Markets** + traductions (pas remplaçables par un seul fichier thème). |
| Contenu | **Uniquement de vrais produits** : pas de fausses données dans le thème ; les démos locales (`previsualisation-maquette`) sont hors Shopify. |
| Cible visuelle | Environ **80 %** de l’esprit produit fini, en t’appuyant sur **tes** produits + metafields. |

---

## 2. Ce dossier = thème Shopify complet (déjà modifié)

**Tu es déjà dans le dossier à zipper ou à pousser en entier** (thème complet avec toutes les modifs).

| Rôle | Fichiers |
|------|----------|
| Marketplace albums | `sections/mozarf-marketplace-albums.liquid`, `assets/mozarf-marketplace.css`, `assets/mozarf-marketplace.js` |
| Modale + JSON album | `snippets/mozarf-marketplace-modal.liquid`, `snippets/mozarf-album-json.liquid` |
| Vitrine accueil | `sections/mozarf-home-showcase-album.liquid` |
| Kits | `sections/mozarf-marketplace-kits.liquid`, `assets/mozarf-kit-centered.css` |
| Gabarits | `templates/collection.mozarf-albums.json`, `templates/collection.mozarf-kits.json`, `templates/product.mozarf-kit.json` |
| Layout | `layout/theme.liquid` — charge `mozarf-kit-centered.css` et la classe `mozarf-kit-centered-template` pour les produits en template **mozarf-kit** |
| Lecteur release (existant) | `sections/mozarf-release-player.liquid`, `assets/mozarf-release.css`, `assets/mozarf-release-player.js`, etc. |

Le dossier `shopify/` à la racine du projet **SITE MOZARF** est une **copie partielle** pour copier-coller ; **ce n’est pas** un thème complet.

---

## 3. Ce que tu configures dans l’admin Shopify

### 3.1 Metafields produit (albums)

**Settings → Custom data → Products** — créer au minimum :

- **`custom.mozarf_album_data`** — type **JSON**  
- Optionnel : **`custom.mozarf_album_blurb`** — texte court (vitrine + cartes)

**Exemple de JSON** (`mozarf_album_data`) :

```json
{
  "title": "Nom affiché dans la modale",
  "featured_image": "https://cdn.shopify.com/s/files/1/.../cover.jpg",
  "tracks": [
    {
      "title": "Track 1",
      "preview_url": "https://cdn.shopify.com/s/files/1/.../extrait.mp3",
      "purchase": {
        "mp3_variant_id": 123456789,
        "wav_variant_id": 123456790,
        "stems_variant_id": 123456791,
        "license_variant_id": 123456792
      }
    }
  ],
  "full_album_variant_id": 123456799,
  "full_album_label": "Full album"
}
```

- Chaque `*_variant_id` est l’**ID de variante Shopify**.  
- `preview_url` = lien **direct** vers un fichier audio (**Contenu → Fichiers**).  
- Laisse `null` ou omets une clé si un format n’existe pas pour ce morceau.

### 3.2 Collections et templates

- Collection **albums** : template **`mozarf-albums`**.  
- Collection **kits** : template **`mozarf-kits`**.  
- Produits **drum kits** : template produit **`mozarf-kit`**.

### 3.3 Page d’accueil

**Personnaliser** → accueil : section **« MOZARF — Home album showcase »** (produit + collection « autres albums » + BeatStars).

### 3.4 Menus

Liens menu vers tes collections `mozarf-albums` et `mozarf-kits`.

### 3.5 BeatStars (défauts modifiables dans les sections)

- [explore-collections](https://www.beatstars.com/explore-collections)  
- [explore-sound-kits](https://www.beatstars.com/explore-sound-kits)

### 3.6 Anglais, devises, langues

[Shopify Markets](https://help.shopify.com/manual/markets) + traductions contenu / thème.

---

## 4. Prévisualisation locale (hors ce zip)

Dans le repo **SITE MOZARF** : `previsualisation-maquette/index.html` (maquette HTML + styles).

---

## 5. Déploiement CLI

Depuis le dossier parent `mozarf-shopify-theme` :

```bash
npx shopify theme push --path theme_export__www-mozarf-com-copie-de-mozarf-theme__10APR2026-1055pm
```

---

## 6. Limites / suite

- Panier : redirection `/cart` après ajout (drawer possible plus tard).  
- Filtres : `snippets/facets.liquid` + filtres collection dans l’admin.

---

*Copie miroir : `MOZARF-LIVRABLE.md` à la racine du projet SITE MOZARF.*
